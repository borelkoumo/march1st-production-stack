#!/usr/bin/env node
'use strict';

require('./create-strapi-app');
