module.exports = {
  resolver: {
    Mutation: {
      createTest: false,
      updateTest: false,
      deleteTest: false,
    },
  },
};
