'use strict';

/**
 * Lifecycle callbacks for the `Category` model.
 */

module.exports = {};
