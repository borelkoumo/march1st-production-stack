'use strict';

/**
 * Lifecycle callbacks for the `Like` model.
 */

module.exports = {};
