'use strict';

/**
 * Lifecycle callbacks for the `Country` model.
 */

module.exports = {};
