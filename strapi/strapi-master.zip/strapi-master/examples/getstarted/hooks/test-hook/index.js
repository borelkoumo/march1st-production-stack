module.exports = () => {
  return {
    initialize() {},
  };
};
